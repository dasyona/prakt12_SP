﻿

#include <iostream>
#include <windows.h>
#include <string>

using namespace std;


struct Process {
    int id;         
    string name;    
    HANDLE h;        // дескриптор процесса
    DWORD pid;       // системный идентификатор процесса
};

Process proc[100];      
int procCount = 0;       
int nextId = 1;          


string get_state(HANDLE h) {
    if (!h) return "освобождён";

    DWORD r = WaitForSingleObject(h, 0);

    if (r == 0) return "завершён";
    return "работает";
}
string exe_folder() {
    char path[MAX_PATH];
    GetModuleFileNameA(NULL, path, MAX_PATH);

    string s = path;
    size_t pos = s.find_last_of("\\");
    if (pos == string::npos) return "";

    return s.substr(0, pos + 1);
}

bool start_process(string path, string args, string title, DWORD flags) {
    if (procCount >= 100) {
        cout << "\nСлишком много процессов (максимум 100)." << endl;
        return false;
    }

    STARTUPINFOA si;
    PROCESS_INFORMATION pi;

    ZeroMemory(&si, sizeof(si));
    si.cb = sizeof(si);
    ZeroMemory(&pi, sizeof(pi));

    string cmd = args;

    if (!CreateProcessA(path.c_str(), &cmd[0], NULL, NULL, FALSE, flags, NULL, NULL, &si, &pi)) {
        cout << "\nОшибка CreateProcess (код " << GetLastError() << ")" << endl;
        return false;
    }


    CloseHandle(pi.hThread);

    // Сохраня
    proc[procCount].id = nextId;
    proc[procCount].name = title;
    proc[procCount].h = pi.hProcess;
    proc[procCount].pid = pi.dwProcessId;

    cout << "\nЗапущен ID=" << nextId << " (PID=" << pi.dwProcessId << "): " << title << endl;

    nextId++;
    procCount++;
    return true;
}

// 1. Диспетчер задач
void start_taskmgr() {
    start_process("C:\\Windows\\System32\\taskmgr.exe", "taskmgr.exe", "taskmgr.exe", 0);
}

// 2. ping.exe с параметрами
void start_ping() {
    string mode, ip, n;

    cout << "\n1) ping <IP>" << endl;
    cout << "2) ping -n <N> <IP>" << endl;
    cout << "3) ping -t <IP>" << endl;
    cout << "Режим: ";
    getline(cin, mode);

    cout << "IP-адрес: ";
    getline(cin, ip);

    string args;

    if (mode == "1") {
        args = "ping.exe " + ip;
    }
    else if (mode == "2") {
        cout << "N: ";
        getline(cin, n);
        args = "ping.exe -n " + n + " " + ip;
    }
    else if (mode == "3") {
        args = "ping.exe -t " + ip;
    }
    else {
        cout << "\nНеверный режим." << endl;
        return;
    }

   
    start_process("C:\\Windows\\System32\\PING.EXE", args, args, CREATE_NEW_CONSOLE);
}

// 3 6
void start_variant6() {
    string a, b;

    cout << "\nНачало диапазона: ";
    getline(cin, a);

    cout << "Конец диапазона: ";
    getline(cin, b);

    // Ищем exe 
    string path = exe_folder() + "Kanaeva_variant6.exe";

   
    string args = "\"" + path + "\" " + a + " " + b;

    start_process(path, args, "Вариант 6 (" + a + " - " + b + ")", CREATE_NEW_CONSOLE);
}

// 4. Список процессов
void show_list() {
    if (procCount == 0) {
        cout << "\nСписок пуст." << endl;
        return;
    }

    cout << "\nСписок процессов:" << endl;

    for (int i = 0; i < procCount; i++) {
        cout << " ID: " << proc[i].id;
        cout << " PID: " << proc[i].pid;
        cout << " Имя: " << proc[i].name;
        cout << " Состояние: " << get_state(proc[i].h) << endl;
    }
}

// 5. Количество работающих процессов
void show_running() {
    int running = 0;

    for (int i = 0; i < procCount; i++) {
        if (get_state(proc[i].h) == "работает") {
            running++;
        }
    }

    cout << "\nРаботающих процессов: " << running << endl;
}

// 6. Принудительное завершение процесса по его ID
void complete_process() {
    int id;

    cout << "\nВведите ID: ";
    cin >> id;
    cin.ignore(); 

    for (int i = 0; i < procCount; i++) {
        if (proc[i].id != id) continue;

        if (get_state(proc[i].h) != "работает") {
            cout << "\nПроцесс уже завершён." << endl;
            return;
        }

        if (!TerminateProcess(proc[i].h, 1)) {
            cout << "\nОшибка TerminateProcess (код " << GetLastError() << ")" << endl;
            return;
        }

   
        WaitForSingleObject(proc[i].h, 3000);
        CloseHandle(proc[i].h);
        proc[i].h = NULL;

        cout << "\nПроцесс ID=" << id << " завершён." << endl;
        return;
    }

    cout << "\nПроцесс с таким ID не найден." << endl;
}

void exit_all() {
    cout << "\nЗавершение работы менеджера..." << endl;

    for (int i = 0; i < procCount; i++) {
        if (!proc[i].h) continue;

        if (get_state(proc[i].h) == "работает") {
            TerminateProcess(proc[i].h, 1);
            WaitForSingleObject(proc[i].h, 3000);
        }

        CloseHandle(proc[i].h);
        proc[i].h = NULL;
    }

    cout << "Все процессы завершены. Выход." << endl;
    ExitProcess(0);
}

int main() {
    setlocale(LC_ALL, "Russian");

    string choice;

    while (true) {
        cout << "\n--- Менеджер процессов" << endl;
        cout << "1 Запустить taskmgr.exe" << endl;
        cout << "2 Запустить ping.exe" << endl;
        cout << "3 Запустить программу варианта 6" << endl;
        cout << "4 Список процессов" << endl;
        cout << "5 Количество работающих" << endl;
        cout << "6 Завершить процесс" << endl;
        cout << "0 Выход" << endl;
        cout << "Выбор: ";

        getline(cin, choice);

        if (choice == "1") start_taskmgr();
        else if (choice == "2") start_ping();
        else if (choice == "3") start_variant6();
        else if (choice == "4") show_list();
        else if (choice == "5") show_running();
        else if (choice == "6") complete_process();
        else if (choice == "0") exit_all();
        else cout << "\nНеверный пункт меню." << endl;
    }

    return 0;
}
