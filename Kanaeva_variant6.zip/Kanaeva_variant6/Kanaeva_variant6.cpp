﻿// Kanaeva_variant6.cpp
// Вариант 6: найти все числа из заданного диапазона,
// у которых сумма цифр равна произведению цифр.
// Границы диапазона передаются аргументами командной строки.

#include <iostream>
#include <string>
#include <conio.h>

using namespace std;

// Проверка одного числа: сумма цифр == произведение цифр
bool is_sum_eq_prod(int n) {
    if (n <= 0) return false;   // 0 и отрицательные не рассматриваем

    int sum = 0;
    long long prod = 1;         // long long, чтобы произведение не переполнилось
    int temp = n;

    while (temp > 0) {
        int digit = temp % 10;  // последняя цифра
        sum += digit;           // прибавляем к сумме
        prod *= digit;          // умножаем в произведение
        temp /= 10;             // отбрасываем последнюю цифру
    }

    return sum == prod;
}

int main(int argc, char* argv[]) {
    setlocale(LC_ALL, "Russian");

    // Менеджер должен передать два числа: начало и конец диапазона
    if (argc < 3) {
        cout << "Ошибка: не переданы границы диапазона." << endl;
        cout << "Запуск: Kanaeva_variant6.exe <начало> <конец>" << endl;
        _getch();
        return 1;
    }

    // stoi переводит строку в число
    int start = stoi(argv[1]);
    int end = stoi(argv[2]);

    // Если границы ввели наоборот - меняем местами
    if (start > end) {
        int t = start;
        start = end;
        end = t;
    }

    int count = 0;
    cout << "Подходящие числа: ";

    for (int i = start; i <= end; i++) {
        if (is_sum_eq_prod(i)) {
            cout << i << " ";
            count++;
        }
    }

    cout << "\nКоличество: " << count << endl;
    cout << "\nНажмите любую клавишу для выхода..." << endl;

    _getch();   // чтобы окно не закрылось сразу после вывода
    return 0;
}
